// Replace the values below with your Firebase web app config from the Firebase Console
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyC5XQ9EfqmizWLG6puHrwfoP5r9dYQAGfo",
      authDomain: "digiworm1.firebaseapp.com",
      projectId: "digiworm1",
      storageBucket: "digiworm1.firebasestorage.app",
      messagingSenderId: "39695170835",
      appId: "1:39695170835:web:e9111fd95eb8656cc12ee6",
      measurementId: "G-6R7EG92E3H",
    );
  }
}
